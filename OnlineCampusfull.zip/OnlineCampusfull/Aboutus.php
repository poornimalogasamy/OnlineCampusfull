<?php

include('header.php');

	
?>

<center>

                       <p align=justify>   The Offcampus management project enables the user to streamline and process the entire recruitment effort of an Colleges. Realizing the pivotal role of Recruitment process plays within college campus, project is designed to maintain campus, process and placement details fitting the recruitment requirement. It is entitled �Online Offcampus� is designed using PHP as front end and My SQL as Back end. A online consultancy maintenance system project is specially designed as per the needs and requirements of Placement Consultancies and Job Providers, includes details of the applicants, Client companies / Organizations, Job Openings, Interview details etc.<p >

</center>

<?php

include('footer.php');

?>


