<div id="footer">
			<div class="left">&copy;  Online Campus. All rights reserved.</div>
			<div class="right">Design by <a href="#">Name</a> + <a href="#"></a></div>
	</div>
	
</div>

<div align=center>This Portal <a href='#'>for Job</a></div></body>
</html>
