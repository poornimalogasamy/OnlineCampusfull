<?php

include('header.php');

	
?>

<center>
<img src="images/headerpeople.gif" width=800>
<br>
<br>
<img src="images/JobSeekersLogo-ButtonForWebsite.jpg"

</center>

<?php

include('footer.php');

?>


